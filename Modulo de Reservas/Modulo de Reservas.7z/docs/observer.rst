observer module
===============

.. automodule:: observer
   :members:
   :undoc-members:
   :show-inheritance:
