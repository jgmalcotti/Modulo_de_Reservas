.. Modulo de Reservas documentation master file, created by
   sphinx-quickstart on Wed Feb 15 17:53:20 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Modulo de Reservas's documentation!
==========================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   controlador
   exp_reg
   modelo
   observer
   vista


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
