exp\_reg module
===============

.. automodule:: exp_reg
   :members:
   :undoc-members:
   :show-inheritance:
