modelo module
=============

.. automodule:: modelo
   :members:
   :undoc-members:
   :show-inheritance:
